#define _STLP_PLATFORM "AIX"
