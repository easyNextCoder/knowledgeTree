#define _STLP_PLATFORM "Free BSD"
