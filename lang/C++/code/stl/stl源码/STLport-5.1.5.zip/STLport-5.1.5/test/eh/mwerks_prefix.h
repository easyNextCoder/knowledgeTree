//mwerks_prefix.h
#define _STLP_NO_FORCE_INSTANTIATE 1// for debugging
#define EH_VECTOR_OPERATOR_NEW 1
#define NDEBUG 1

#if __MWERKS__ >= 0x3000
#include <MSLCarbonPrefix.h>
#endif